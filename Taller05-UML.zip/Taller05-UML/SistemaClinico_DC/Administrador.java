package SistemaClinico_DC;

public class Administrador extends Persona{

    public Administrador(){
        
    }

    public void RegistrarUsuario(){

    }

    public void AsignarRol(Persona p){

    }

}