package SistemaClinico_DC;

public class AreaMedica {
    
    protected String especialidad;
    protected float costo;

    public AreaMedica(){}
}
