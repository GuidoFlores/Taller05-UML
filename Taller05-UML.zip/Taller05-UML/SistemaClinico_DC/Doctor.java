package SistemaClinico_DC;

public class Doctor {
    protected int RegDoctor;
    protected String Especialidad;

    public Doctor(){

    }
    
    public void Recetar(){

    } 

    public void AgregarPlanNut(){
        
    } 

    public void ImprimirReceta(){
        
    } 

    public void RegistraSecretaria(){
        
    } 
}
