package SistemaClinico_DC;

public class Paciente extends Persona{
    
    protected String email;

    public Paciente(){

    }

    public boolean SolicitarCita(){
        return true;
    }
    

}
