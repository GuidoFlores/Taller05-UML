package SistemaClinico_DC;

public interface Pago {
    public abstract boolean RealizarPago(float Monto);
}
