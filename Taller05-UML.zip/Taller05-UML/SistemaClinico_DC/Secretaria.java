package SistemaClinico_DC;

public class Secretaria {
    
    public Secretaria(){

    }

    public void VerificarCita(){

    }

    public void AgendarCita(){
        
    }
}
